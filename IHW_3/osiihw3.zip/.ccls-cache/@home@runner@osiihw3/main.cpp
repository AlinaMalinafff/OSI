#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>

#define PORT 8080
#define BUFFER_SIZE 1024

// Состояние пчелы
typedef enum {
    IDLE,  // Бездействует
    COLLECTING,  // Собирает мед
    GUARDING  // Сторожит улей
} BeeState;

// Состояние улья
typedef struct {
    int beeCount;  // Количество пчел в улье
    int honeyCount;  // Количество меда в улье
} HiveState;

// Состояние Вини-Пуха
typedef struct {
    int honeyNeeded;  // Необходимое количество меда для пробуждения
    int isAwake;  // Флаг, показывающий, бодрствует ли Вини-Пух
    int honeyTaken;  // Количество меда, которое Вини-Пух забрал
} WinnieState;

// Структура данных пчелы
typedef struct {
    int id;  // Идентификатор пчелы
    BeeState state;  // Текущее состояние пчелы
    pthread_t thread;  // Поток пчелы
} Bee;

// Функция обработки сообщений пчелы
void *beeHandler(void *arg) {
    Bee *bee = (Bee *)arg;
    int sockfd;
    struct sockaddr_in serverAddr;
    char buffer[BUFFER_SIZE];

    // Создание сокета
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        perror("Ошибка создания сокета");
        exit(1);
    }

    // Заполнение адреса сервера
    memset(&serverAddr, 0, sizeof(serverAddr));
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1");  // Замените на реальный адрес сервера
    serverAddr.sin_port = htons(PORT);

    // Подключение к серверу
    if (connect(sockfd, (struct sockaddr *)&serverAddr, sizeof(serverAddr)) < 0) {
        perror("Ошибка подключения к серверу");
        exit(1);
    }

    // Отправка сообщения о присоединении пчелы
    sprintf(buffer, "%d a", bee->id);
    send(sockfd, buffer, strlen(buffer), 0);

    // Цикл обработки действий пчелы
    while (1) {
        // Проверка состояния пчелы
        if (bee->state == IDLE) {
            // Пчела ждет, пока не станет доступным действие
            sleep(1);
        } else if (bee->state == COLLECTING) {
            // Пчела собирает мед и отправляет сообщение серверу
            sprintf(buffer, "%d c", bee->id);
            send(sockfd, buffer, strlen(buffer), 0);
            sleep(1);
        } else if (bee->state == GUARDING) {
            // Пчела сторожит улей и отправляет сообщение серверу
            sprintf(buffer, "%d g", bee->id);
            send(sockfd, buffer, strlen(buffer), 0);
            sleep(1);
        }

        // Проверка, не пора ли пчеле покинуть улей
        if (bee->state != IDLE && rand() % 10 == 0) {
            // Пчела покидает улей и отправляет сообщение серверу
            sprintf(buffer, "%d l", bee->id);
            send(sockfd, buffer, strlen(buffer), 0);
            break;
        }
    }

    close(sockfd);
    return NULL;
}

// Функция обработки сообщений Вини-Пуха
void *winnieHandler(void *arg) {
    int sockfd;
    struct sockaddr_in serverAddr;
    char buffer[BUFFER_SIZE];
    WinnieState *winnie = (WinnieState *)arg;

    // Создание сокета
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        perror("Ошибка создания сокета");
        exit(1);
    }

    // Заполнение адреса сервера
    memset(&serverAddr, 0, sizeof(serverAddr));
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1");  // Замените на реальный адрес сервера
    serverAddr.sin_port = htons(PORT);

    // Подключение к серверу
    if (connect(sockfd, (struct sockaddr *)&serverAddr, sizeof(serverAddr)) < 0) {
        perror("Ошибка подключения к серверу");
        exit(1);
    }

    // Цикл обработки действий Вини-Пуха
    while (1) {
        // Проверка состояния Вини-Пуха
        if (winnie->isAwake) {
            // Вини-Пух пытается забрать мед и отправляет сообщение серверу
            sprintf(buffer, "-1 t");
            send(sockfd, buffer, strlen(buffer), 0);
            sleep(1);
        } else {
            // Вини-Пух спит
            sleep(2);
        }

        // Проверка, не пора ли Вини-Пуху лечиться
        if (winnie->isAwake && rand() % 10 == 0) {
            // Вини-Пух был укушен, отправляет сообщение серверу
            sprintf(buffer, "-1 f");
            send(sockfd, buffer, strlen(buffer), 0);
            sleep(5); // Лечение укуса
        }
    }

    close(sockfd);
    return NULL;
}

// Функция обработки сообщений сервера
void *serverHandler(void *arg) {
    int sockfd = *(int *)arg;
    HiveState hive;
    WinnieState winnie;
    Bee bees[100]; // Достаточно для 100 пчел (изменить, если нужно)
    int beeCount = 0;

    // Инициализация состояния улья и Вини-Пуха
    hive.beeCount = 0;
    hive.honeyCount = 0;
    winnie.honeyNeeded = 15; // Половина от 30
    winnie.isAwake = 0;
    winnie.honeyTaken = 0;

    while (1) {
        char buffer[BUFFER_SIZE];
        int bytesRead = recv(sockfd, buffer, BUFFER_SIZE, 0);

        if (bytesRead <= 0) {
            printf("Сервер: Соединение закрыто.\n");
            break;
        }

        // Разбор сообщения
        char *token = strtok(buffer, " ");
        int senderId = atoi(token);
        token = strtok(NULL, " ");
        char *action = token;

        // Обработка сообщений от пчел
        if (senderId > 0) {
            // Добавление новой пчелы
            if (action[0] == 'a') {
                bees[beeCount].id = senderId;
                bees[beeCount].state = IDLE;
                pthread_create(&bees[beeCount].thread, NULL, beeHandler, &bees[beeCount]);
                beeCount++;
                hive.beeCount++;
                printf("Сервер: Новая пчела присоединилась (ID: %d)\n", senderId);
            }
            // Пчела собирает мед
            if (action[0] == 'c') {
                hive.honeyCount++;
                bees[senderId - 1].state = COLLECTING;
                printf("Сервер: Пчела %d собрала мед (Мед: %d)\n", senderId, hive.honeyCount);
            }
            // Пчела сторожит улей
            if (action[0] == 'g') {
                bees[senderId - 1].state = GUARDING;
                printf("Сервер: Пчела %d сторожит улей\n", senderId);
            }
            // Пчела покидает улей
            if (action[0] == 'l') {
                hive.beeCount--;
                bees[senderId - 1].state = IDLE;
                printf("Сервер: Пчела %d покинула улей\n", senderId);
            }
        }

        // Обработка сообщения от Вини-Пуха
        if (senderId == -1) {
            // Пробуждение Вини-Пуха
            if (action[0] == 'w') {
                winnie.isAwake = 1;
                printf("Сервер: Вини-Пух проснулся\n");
            }
            // Вини-Пух забрал мед
            if (action[0] == 't') {
                winnie.honeyTaken = hive.honeyCount;
                hive.honeyCount = 0;
                printf("Сервер: Вини-Пух забрал весь мед (%d порций)\n", winnie.honeyTaken);
            }
        }

        // Проверка состояния улья и отправка сообщений клиентам
        if (hive.honeyCount >= winnie.honeyNeeded && !winnie.isAwake) {
            // Отправка сообщения Вини-Пуху о пробуждении
            char msg[BUFFER_SIZE];
            sprintf(msg, "-1 w");
            send(sockfd, msg, strlen(msg), 0);
            winnie.isAwake = 1;
            printf("Сервер: Вини-Пух проснулся (Мед: %d)\n", hive.honeyCount);
        }

        if (winnie.isAwake && hive.beeCount < 3) {
            // Отправка сообщения Вини-Пуху о забирании меда
            char msg[BUFFER_SIZE];
            sprintf(msg, "-1 t");
            send(sockfd, msg, strlen(msg), 0);
            winnie.isAwake = 0;
            winnie.honeyTaken = hive.honeyCount;
            hive.honeyCount = 0;
            printf("Сервер: Вини-Пух забрал весь мед (Мед: %d)\n", winnie.honeyTaken);
        } else if (winnie.isAwake && hive.beeCount >= 3) {
            // Отправка сообщения Вини-Пуху о том, что его укусили
            char msg[BUFFER_SIZE];
            sprintf(msg, "-1 f");
            send(sockfd, msg, strlen(msg), 0);
            winnie.isAwake = 0;
            printf("Сервер: Вини-Пух был укушен\n");
        }

        // Проверка количества меда в улье
        if (hive.honeyCount >= 30) {
            printf("Сервер: Улей переполнен медом!\n");
            break;
        }

        // Отправка сообщений пчелам о действиях
        for (int i = 0; i < beeCount; i++) {
            // Пчела не может покинуть улей, если она единственная
            if (hive.beeCount == 1 && bees[i].state == GUARDING) {
                char msg[BUFFER_SIZE];
                sprintf(msg, "%d g", bees[i].id);
                send(sockfd, msg, strlen(msg), 0);
            } else if (hive.honeyCount < 30 && bees[i].state == IDLE) {
                // Отправка сообщения пчеле о сборе меда
                char msg[BUFFER_SIZE];
                sprintf(msg, "%d c", bees[i].id);
                send(sockfd, msg, strlen(msg), 0);
            } else if (hive.honeyCount < 30 && bees[i].state == GUARDING) {
                // Отправка сообщения пчеле о продолжении охраны
                char msg[BUFFER_SIZE];
                sprintf(msg, "%d g", bees[i].id);
                send(sockfd, msg, strlen(msg), 0);
            }
        }
    }
    close(sockfd);
    return NULL;
}

// Функция запуска сервера
int startServer(char *ip, int port) {
    int sockfd, newsockfd;
    struct sockaddr_in serverAddr, clientAddr;
    socklen_t clientAddrLen;
    pthread_t thread;

    // Создание сокета
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        perror("Ошибка создания сокета");
        exit(1);
    }

    // Заполнение адреса сервера
    memset(&serverAddr, 0, sizeof(serverAddr));
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = inet_addr(ip);
    serverAddr.sin_port = htons(port);

    // Привязка сокета к адресу
    if (bind(sockfd, (struct sockaddr *)&serverAddr, sizeof(serverAddr)) < 0) {
        perror("Ошибка привязки сокета");
        exit(1);
    }

    // Прослушивание входящих соединений
    listen(sockfd, 5);
    clientAddrLen = sizeof(clientAddr);

    printf("Сервер запущен на %s:%d\n", ip, port);

    while (1) {
        // Принятие нового соединения
        newsockfd = accept(sockfd, (struct sockaddr *)&clientAddr, &clientAddrLen);
        if (newsockfd < 0) {
            perror("Ошибка принятия соединения");
            continue;
        }

        // Создание нового потока для обработки соединения
        pthread_create(&thread, NULL, serverHandler, &newsockfd);
    }

    close(sockfd);
    return 0;
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Использование: %s <IP-адрес> <порт>\n", argv[0]);
        return 1;
    }

    // Запуск сервера
    startServer(argv[1], atoi(argv[2]));

    return 0;
}