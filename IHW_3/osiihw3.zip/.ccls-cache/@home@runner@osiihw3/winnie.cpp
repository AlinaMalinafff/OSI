#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>

#define PORT 8080
#define BUFFER_SIZE 1024

// Состояние Вини-Пуха
typedef struct {
    int honeyNeeded;  // Необходимое количество меда для пробуждения
    int isAwake;  // Флаг, показывающий, бодрствует ли Вини-Пух
    int honeyTaken;  // Количество меда, которое Вини-Пух забрал
    pthread_t thread; // Поток Вини-Пуха
} WinnieState;

// Функция обработки сообщений Вини-Пуха
void *winnieHandler(void *arg) {
    int sockfd;
    struct sockaddr_in serverAddr;
    char buffer[BUFFER_SIZE];
    WinnieState *winnie = (WinnieState *)arg;

    // Создание сокета
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        perror("Ошибка создания сокета");
        exit(1);
    }

    // Заполнение адреса сервера
    memset(&serverAddr, 0, sizeof(serverAddr));
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1");  // Замените на реальный адрес сервера
    serverAddr.sin_port = htons(PORT);

    // Подключение к серверу
    if (connect(sockfd, (struct sockaddr *)&serverAddr, sizeof(serverAddr)) < 0) {
        perror("Ошибка подключения к серверу");
        exit(1);
    }

    // Цикл обработки действий Вини-Пуха
    while (1) {
        // Проверка состояния Вини-Пуха
        if (winnie->isAwake) {
            // Вини-Пух пытается забрать мед и отправляет сообщение серверу
            sprintf(buffer, "-1 t");
            send(sockfd, buffer, strlen(buffer), 0);
            sleep(1);
        } else {
            // Вини-Пух спит
            sleep(2);
        }

        // Проверка, не пора ли Вини-Пуху лечиться
        if (winnie->isAwake && rand() % 10 == 0) {
            // Вини-Пух был укушен, отправляет сообщение серверу
            sprintf(buffer, "-1 f");
            send(sockfd, buffer, strlen(buffer), 0);
            sleep(5); // Лечение укуса
        }
    }

    close(sockfd);
    return NULL;
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Использование: %s <IP-адрес> <порт>\n", argv[0]);
        return 1;
    }

    char *serverIp = argv[1];
    int serverPort = atoi(argv[2]);

    // Создание сокета
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        perror("Ошибка создания сокета");
        exit(1);
    }

    // Заполнение адреса сервера
    struct sockaddr_in serverAddr;
    memset(&serverAddr, 0, sizeof(serverAddr));
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = inet_addr(serverIp);
    serverAddr.sin_port = htons(serverPort);

    // Подключение к серверу
    if (connect(sockfd, (struct sockaddr *)&serverAddr, sizeof(serverAddr)) < 0) {
        perror("Ошибка подключения к серверу");
        exit(1);
    }

    // Создание Вини-Пуха
    WinnieState winnie;
    winnie.honeyNeeded = 15; // Половина от 30
    winnie.isAwake = 0;
    winnie.honeyTaken = 0;

    // Запуск потока для обработки действий Вини-Пуха
    pthread_create(&winnie.thread, NULL, winnieHandler, &winnie);

    // Ожидание завершения потока Вини-Пуха
    pthread_join(winnie.thread, NULL);

    close(sockfd);
    return 0;
}