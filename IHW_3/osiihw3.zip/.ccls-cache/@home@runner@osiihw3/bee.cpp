#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>

#define PORT 8080
#define BUFFER_SIZE 1024

// Состояние пчелы
typedef enum {
    IDLE,  // Бездействует
    COLLECTING,  // Собирает мед
    GUARDING  // Сторожит улей
} BeeState;

// Структура данных пчелы
typedef struct {
    int id;  // Идентификатор пчелы
    BeeState state;  // Текущее состояние пчелы
    pthread_t thread;  // Поток пчелы
} Bee;

// Функция обработки сообщений пчелы
void *beeHandler(void *arg) {
    Bee *bee = (Bee *)arg;
    int sockfd;
    struct sockaddr_in serverAddr;
    char buffer[BUFFER_SIZE];

    // Создание сокета
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        perror("Ошибка создания сокета");
        exit(1);
    }

    // Заполнение адреса сервера
    memset(&serverAddr, 0, sizeof(serverAddr));
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1");  // Замените на реальный адрес сервера
    serverAddr.sin_port = htons(PORT);

    // Подключение к серверу
    if (connect(sockfd, (struct sockaddr *)&serverAddr, sizeof(serverAddr)) < 0) {
        perror("Ошибка подключения к серверу");
        exit(1);
    }

    // Отправка сообщения о присоединении пчелы
    sprintf(buffer, "%d a", bee->id);
    send(sockfd, buffer, strlen(buffer), 0);

    // Цикл обработки действий пчелы
    while (1) {
        // Проверка состояния пчелы
        if (bee->state == IDLE) {
            // Пчела ждет, пока не станет доступным действие
            sleep(1);
        } else if (bee->state == COLLECTING) {
            // Пчела собирает мед и отправляет сообщение серверу
            sprintf(buffer, "%d c", bee->id);
            send(sockfd, buffer, strlen(buffer), 0);
            sleep(1);
        } else if (bee->state == GUARDING) {
            // Пчела сторожит улей и отправляет сообщение серверу
            sprintf(buffer, "%d g", bee->id);
            send(sockfd, buffer, strlen(buffer), 0);
            sleep(1);
        }

        // Проверка, не пора ли пчеле покинуть улей
        if (bee->state != IDLE && rand() % 10 == 0) {
            // Пчела покидает улей и отправляет сообщение серверу
            sprintf(buffer, "%d l", bee->id);
            send(sockfd, buffer, strlen(buffer), 0);
            break;
        }
    }

    close(sockfd);
    return NULL;
}

int main(int argc, char *argv[]) {
    if (argc != 4) {
        printf("Использование: %s <ID_пчелы> <IP-адрес> <порт>\n", argv[0]);
        return 1;
    }

    int beeId = atoi(argv[1]);
    char *serverIp = argv[2];
    int serverPort = atoi(argv[3]);

    // Создание сокета
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        perror("Ошибка создания сокета");
        exit(1);
    }

    // Заполнение адреса сервера
    struct sockaddr_in serverAddr;
    memset(&serverAddr, 0, sizeof(serverAddr));
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = inet_addr(serverIp);
    serverAddr.sin_port = htons(serverPort);

    // Подключение к серверу
    if (connect(sockfd, (struct sockaddr *)&serverAddr, sizeof(serverAddr)) < 0) {
        perror("Ошибка подключения к серверу");
        exit(1);
    }

    // Отправка сообщения о присоединении пчелы
    char buffer[BUFFER_SIZE];
    sprintf(buffer, "%d a", beeId);
    send(sockfd, buffer, strlen(buffer), 0);

    // Создание пчелы
    Bee bee;
    bee.id = beeId;
    bee.state = IDLE;

    // Запуск потока для обработки действий пчелы
    pthread_create(&bee.thread, NULL, beeHandler, &bee);

    // Ожидание завершения потока пчелы
    pthread_join(bee.thread, NULL);

    close(sockfd);
    return 0;
}